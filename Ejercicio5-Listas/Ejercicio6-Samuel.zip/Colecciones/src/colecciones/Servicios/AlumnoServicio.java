/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones.Servicios;

import colecciones.Entidad.Alumno;
import java.util.ArrayList;
import java.util.Scanner;

public class AlumnoServicio {
     ArrayList<Alumno> alum;
     Scanner valor = new Scanner(System.in);
     public AlumnoServicio(){
         alum=new ArrayList();
     }
     
      public void crearAlumno() {      
        System.out.println("Nombre: ");
        String nombre = valor.next();
         ArrayList<Integer> notass = new ArrayList();
         System.out.println("Nota 1: ");
         notass.add(valor.nextInt());
         System.out.println("Nota 2: ");
         notass.add(valor.nextInt());
         System.out.println("Nota 3: ");
         notass.add(valor.nextInt());
         Alumno alumnoo = new Alumno(nombre,notass);
         alum.add(alumnoo);
    }
      
      public void buscar(){
        System.out.println("Ingrese nombre: ");
        String nom=valor.next();        
        for (Alumno alumss : alum) {
            if(alumss.getNombre().equals(nom)){                    
                    System.out.println("promedio es "+ alumss.notaFinal());
            }
        }                                                                                       
    }    
}
