/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones.Servicios;

import colecciones.Entidad.Pelicula;
import java.util.ArrayList;
import java.util.Scanner;

public class PeliculaServicio {

    ArrayList<Pelicula> pelicula;

    public PeliculaServicio() {
        pelicula = new ArrayList();
    }

    public void crearPelicula() {
        Scanner valor = new Scanner(System.in);
        System.out.println("Titulo de la pelicula: ");
        String title = valor.nextLine();
        System.out.println("Director de la pelicula: ");
        String direc = valor.nextLine();
        System.out.println("Duracion de la pelicula");
        Integer duracion = valor.nextInt();
        Pelicula pel = new Pelicula(title, direc, duracion);
        pelicula.add(pel);
        System.out.println("Desea ingresar otra pelicula s/n");
        char letra = valor.next().charAt(0);             
        while (letra == 's') {
            valor.nextLine();
            System.out.println("Titulo de la pelicula: ");
            title = valor.nextLine();
            System.out.println("Director de la pelicula: ");
            direc = valor.nextLine();
            System.out.println("Duracion de la pelicula");
            duracion = valor.nextInt();
            pel = new Pelicula(title, direc, duracion);
            pelicula.add(pel);
            System.out.println("Desea ingresar otra pelicula s/n");
            letra = valor.next().charAt(0);
        }        
    }
    
    public void mostrar(){
            System.out.println(pelicula.toString());            
    }
    
    public void mayor1Hora(){                      
         for (Pelicula pelicula1 : pelicula) {
               if(pelicula1.getDuracion()>60){
                   //System.out.println("1: "+pelicula1.toString());
                   System.out.println("Pelicula: "+pelicula1.getTitulo());
               }
        }         
    }
    
    public void OrdenarHoraMenorMayor(){
        pelicula.sort(Pelicula.compararDuracion);
        for (Pelicula pelicula1 : pelicula) {
             System.out.println("Pelicula: "+pelicula1.getTitulo());
        }        
    }
    
    
    public void OrdenarHoraMayorMenor(){
        pelicula.sort(Pelicula.compararDuracion2);
        for (Pelicula pelicula1 : pelicula) {
            System.out.println("Pelicula"+pelicula1.getTitulo());
        }
    }
    
    public void OrdenarTitulo(){
       pelicula.sort(Pelicula.compararAlfabeticamenteTitulo);
        for (Pelicula pelicula1 : pelicula) {
            System.out.println("Pelicula: "+pelicula1.getTitulo());
        }
    }
    
     public void OrdenarDirector(){
       pelicula.sort(Pelicula.compararDirector);
        for (Pelicula pelicula1 : pelicula) {
            System.out.println("Pelicula: "+pelicula1.getDirector());
        }
    }
    
}
