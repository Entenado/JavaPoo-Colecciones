/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones.Servicios;

import colecciones.Entidad.Producto;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class ServicioEj6 {

    Scanner valor = new Scanner(System.in);
    HashMap<Integer, Producto> producto = new HashMap();
    Producto aux;

    public void crearObjeto() {
        Scanner p = new Scanner(System.in);
        char aux2;
        do {
            System.out.println("Ingrese nombre del producto: ");
            String nomb = p.nextLine();
            System.out.println("Ingrese precio: ");
            Integer precio = p.nextInt();
            System.out.println("Ingrese la llave del producto: ");
            Integer llave = p.nextInt();
            aux = new Producto(precio, nomb);
            producto.put(llave, aux);
            System.out.println("Desea ingresar otro producto  s/n");
            aux2 = p.next().charAt(0);
        } while (aux2 == 's');
    }

    public void modificarPrecio(Integer key) {
        Producto aux2;
        Integer prec;
        System.out.println("Ingrese el precio: ");
        prec = valor.nextInt();
        if (producto.containsKey(key)) {
            aux2 = new Producto(prec, aux.getNombre());
            producto.put(key, aux2);
        }
    }

    public void eliminar(Integer key) {
        producto.remove(key);
    }

    public void mostrar() {
        for (Map.Entry<Integer, Producto> entry : producto.entrySet()) {
            Integer key = entry.getKey();
            Producto value = entry.getValue();
            System.out.println("Llave: " + key + " Producto: " + value);
        }
    }
}
