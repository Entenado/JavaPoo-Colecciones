/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones;

import colecciones.Entidad.Alumno;
import colecciones.Servicios.AlumnoServicio;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class Ej3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AlumnoServicio aux = new AlumnoServicio();
        Scanner valor = new Scanner(System.in);
        Alumno alum=new Alumno();       
        char letra;
         boolean bandera=true;
        while (bandera) {
           aux.crearAlumno();
           System.out.println("Desea ingresar persona s/n");
            char l = valor.nextLine().charAt(0);
            if(!(l=='s')){                
                   bandera=false;
            }
        }
        aux.buscar();
    }
        
        
//        do {
//            aux.crearAlumno();
//            System.out.println("Desea ingreasr otra persona  s/n");
//            letra = valor.nextLine().charAt(0);
//        } while (letra =='s');
//        
        
 
    
}
