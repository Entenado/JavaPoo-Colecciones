/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones.Entidad;

import java.util.ArrayList;

/**
 *
 * @author Samuel
 */
public class Alumno {   
    private  String nombre;       
    private ArrayList<Integer> nota;

    public Alumno() {
    
    }

    
    public Alumno(String nombre, ArrayList<Integer> nota) {
        this.nombre = nombre;
        this.nota = nota;
    }

    public Alumno(String nombre) {
        this.nombre = nombre;
    }

    public Alumno(ArrayList<Integer> nota) {
        this.nota = nota;
    }
    
    

    public String getNombre() {
        return nombre;
    }

    public ArrayList<Integer> getNota() {
        return nota;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNota(ArrayList<Integer> nota) {
        this.nota = nota;
    }
    
    public double notaFinal(){
        int sum=0;
        for(int notas:nota){
                sum =sum+notas;
        }
             return  (double) sum/nota.size();
    }                    
}
